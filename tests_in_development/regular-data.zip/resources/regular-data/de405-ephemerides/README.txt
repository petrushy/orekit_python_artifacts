The files in this directory are test files only.
They should NOT be used for anything but test purposes.

The Chebyshev coefficients are real ones extracted from the official
JPL files unxp1950.405 and unxp2000.405, but the headers have been
edited and the files have been truncated for test purposes.

The files ranges are as follows:

     file name                start epoch                        end epoch
    unxp0000.405    1969-05-27T00:00:00.000 (TDB)      1969-10-02T00:00:00.000 (TDB)
    unxp0001.405    1969-12-05T00:00:00.000 (TDB)      1970-04-12T00:00:00.000 (TDB)
    unxp0002.405    1970-06-15T00:00:00.000 (TDB)      1970-08-18T00:00:00.000 (TDB)
    unxp0003.405    2002-12-16T00:00:00.000 (TDB)      2004-02-05T00:00:00.000 (TDB)

The original files can be found on the JPL FTP server:
  ftp://ssd.jpl.nasa.gov/pub/eph/planets/unix/de405
