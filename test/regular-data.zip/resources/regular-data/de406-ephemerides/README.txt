The file in this directory is a test file only.
It should NOT be used for anything but test purposes.

The Chebyshev coefficients are real ones extracted from the official
JPL file unxp2700.406, but the header has been edited and the file
has been truncated for test purposes.

The file range is as follows:

     file name                start epoch                        end epoch
    unxp0000.406    2964-06-03T00:00:00.000 (TDB)      2965-02-14T00:00:00.000 (TDB)

The original files can be found on the JPL FTP server:
  ftp://ssd.jpl.nasa.gov/pub/eph/planets/unix/de406
