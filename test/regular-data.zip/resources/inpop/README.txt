The files in this directory are test files only.
They should NOT be used for anything but test purposes.

The Chebyshev coefficients are real ones extracted from the official
INPOP 10B files, but the headers have been
edited and the files have been truncated for test purposes.

The original files can be found on the IMCCE FTP server:
  ftp://ftp.imcce.fr/pub/ephem/planets/inpop10b