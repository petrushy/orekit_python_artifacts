This EGM96 coefficients file is from
http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm96/egm96.html
